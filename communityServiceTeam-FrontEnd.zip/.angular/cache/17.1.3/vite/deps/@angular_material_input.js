import {
  MAT_INPUT_VALUE_ACCESSOR,
  MatInput,
  MatInputModule,
  getMatInputUnsupportedTypeError
} from "./chunk-JKJFARJP.js";
import {
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix
} from "./chunk-BLUYSK6W.js";
import "./chunk-LAS4YMFX.js";
import "./chunk-VSB2ZBSE.js";
import "./chunk-X7X7G2FO.js";
import "./chunk-GXDAUNNK.js";
import "./chunk-JK3APCRM.js";
import "./chunk-V2MCY3ZS.js";
export {
  MAT_INPUT_VALUE_ACCESSOR,
  MatError,
  MatFormField,
  MatHint,
  MatInput,
  MatInputModule,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatInputUnsupportedTypeError
};
//# sourceMappingURL=@angular_material_input.js.map
