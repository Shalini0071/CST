import { Directive, ElementRef, Renderer2 } from '@angular/core';

@Directive({
  selector: '[appElevated]'
})
export class ElevatedDirective {


  constructor(private el: ElementRef, private renderer: Renderer2) { 
    this.renderer.setStyle(el.nativeElement,'box-shadow','1px 1px 3px -1px');
  }

}
