import { Component } from '@angular/core';

@Component({
  selector: 'app-basic',
  templateUrl: './basic.component.html',
  styleUrl: './basic.component.css'
})
export class BasicComponent {
  filteredObj:any;

  onFilteredObj(filteredOBJ:any){
   this.filteredObj=filteredOBJ;
  }
}
