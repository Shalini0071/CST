import { AfterViewInit, Component, Input, OnChanges, SimpleChanges, ViewChild } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatDatepicker } from '@angular/material/datepicker';
import { DateUtil } from '../commonUtils/DateUtil';
import { ClientService } from '../client.service';
import { MatSnackBar } from '@angular/material/snack-bar';


@Component({
  selector: 'app-edit-client',
  templateUrl: './edit-client.component.html',
  styleUrl: './edit-client.component.css'
})
export class EditClientComponent implements OnChanges, AfterViewInit {

  @ViewChild('picker') picker: any;
  @Input() filteredObj: any;
 
  constructor(private  _clientService:ClientService, private snackBar:MatSnackBar){

  }

  Indigenous: any;
  pwd: any;
  vet: any;
  sheltered: any;
  bus: any;
  clothing: any;
  pet: any;
  PSSG: any;

  ngAfterViewInit(): void {
    console.log(this.picker);
  }
  selectedOption: string = '';
  dateOfBirth!: Date;

  ngOnChanges(changes: SimpleChanges): void {
    this.filteredObj = changes['filteredObj'].currentValue;
    this.selectedOption = this.filteredObj?.client[0].gender.toString();
    this.dateOfBirth = DateUtil.convertToDate('15-Mar-78');
    this.Indigenous=this.filteredObj?.client[0].indigenous;
    this.pwd=this.filteredObj?.client[0].pwd;
    this.vet=this.filteredObj?.client[0].vet;
    this.sheltered=this.filteredObj?.client[0].emergencySheltered;
    this.bus=this.filteredObj?.client[0].deposit;
    this.clothing=this.filteredObj?.client[0].clothing;
    this.pet=this.filteredObj?.client[0].pet;
    this.PSSG=this.filteredObj?.client[0].pssg;

    console.log(changes);
  }

  setDate(date: any) {
    this.dateOfBirth = date.value;
    console.log(this.dateOfBirth);
  }

  save(){
    console.log('triggering save...');
    console.log(this.filteredObj?.client[0]);
    this._clientService.saveClient(this.filteredObj?.client[0]).subscribe(res=>{
      if(res&&res.status==200){
        this.snackBar.open('Saved successfully!');
      }else{
        this.snackBar.open('Error Saving cliet! Are the information valid?');
      }
    })
  }


  delete(){
    console.log('triggering delete...');
    console.log(this.filteredObj?.client[0]);
    this._clientService.deleteClient(this.filteredObj?.client[0].clientId).subscribe(res=>{
      if(res&&res.status==200){
        this.snackBar.open('Deleted successfully!');
      }else{
        this.snackBar.open('Error Deleting cliet! Are the information valid?');
      }
    })
  }

  restClientData(){
   window.location.reload();
    

  }

}
