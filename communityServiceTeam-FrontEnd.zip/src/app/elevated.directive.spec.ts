import { ElevatedDirective } from './elevated.directive';

describe('ElevatedDirective', () => {
  it('should create an instance', () => {
    const directive = new ElevatedDirective();
    expect(directive).toBeTruthy();
  });
});
