import { AfterViewInit, Component, ViewChild } from '@angular/core';
import { client } from '../models/Client';
import { Gender } from '../models/Gender';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { ClientService } from '../client.service';

@Component({
  selector: 'app-client-list',
  templateUrl: './client-list.component.html',
  styleUrl: './client-list.component.css'
})
export class ClientListComponent implements AfterViewInit {
  constructor(private clientService:ClientService){

  }
  ngAfterViewInit(): void {
    this.dataSource.paginator=this.paginator;
  }
  
  @ViewChild(MatPaginator) paginator: MatPaginator | any;
  
  clients: client[] = this.clientService.getClientsArray();

  

  displayedColumns=['Client ID', 'First Name', 'Last Name', 'City', 'Gender', 'Date of Birth','Year'];
  dataSource = new MatTableDataSource<client>(this.clients);


}

