import { Gender } from "./Gender";

export interface client{
  
    id?:string,
    clientId:string,
    firstName:string,
    lastName:string,
    gender:Gender,
    dateOfBirth:Date,
    city:string,
    year:string,
    pwd:boolean,
    vet:boolean,
    emergencySheltered:boolean,
    clothing:boolean,
    pet:boolean,
    deposit:boolean,
    pssg:boolean,
    status:boolean,
    deceased:boolean,
    active:boolean,
    indigenous:boolean

}

