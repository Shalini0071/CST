export enum Gender{
    MALE="male",
    FEMALE="female",
    NON_BINARY="nonBinary",
    PREFER_NOT_TO_SAY="preferNotToSay",
    GENDER_QUEER="genderqueer",
    GENDER_FLUID="genderfluid",
    AGENDER="agender",
    TRANS_MALE_TO_FEMALE="transMaleToFemale",
    TRANS_FEMALE_TO_MALE="transFemaleToMale",
    TWO_SPIRIT="twoSpirit"

}
