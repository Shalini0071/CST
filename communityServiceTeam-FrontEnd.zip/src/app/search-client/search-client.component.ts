import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormControl, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { client } from '../models/Client';
import { Gender } from '../models/Gender';
import { ClientService } from '../client.service';

@Component({
  selector: 'app-search-client',
  templateUrl: './search-client.component.html',
  styleUrl: './search-client.component.css'
})
export class SearchClientComponent {
  myControl = new FormControl('');
  clients: any =[];
  filteredClientsName!: Observable<string[]>;
  @Output() filteredObj: EventEmitter<any> = new EventEmitter();
  filteredByField!: string;

  constructor(private clientService:ClientService){
    
  }

  ngOnInit() {
    this.clientService.getAllClients().subscribe(res=>{
      if(res&&res.status==200){
        
        this.clients=this.clientService.getClientsArray()?this.clientService.getClientsArray():[];
        this.filteredClientsName = this.myControl.valueChanges.pipe(
          startWith(''), 
          map(
            value => {
              let results = this.clients.filter(client => client.clientId.includes(value||'')).flatMap(innerClient=>innerClient.firstName+" "+innerClient.lastName);
              if (results?.length > 0) {
                this.filteredByField=('clientId');
                return results;
              } else {
                results = this.clients.filter(client => client.firstName.includes(value || '')).flatMap(innerClient=>innerClient.firstName+" "+innerClient.lastName);
                if (results?.length > 0) {
                  this.filteredByField=('firstName');
                  return results;
                } else {
                  results = this.clients.filter(client => client.lastName.includes(value || '')).flatMap(innerClient=>innerClient.firstName+" "+innerClient.lastName);
                  if (results?.length > 0) {
                    this.filteredByField=('lastName');
                    return results;
                  } else {
                    this.filteredByField=('none');
                    return [];
                  }
                }
    
              }
            }
          )
    
        );
      }
    })
    
    
  }

  search(){
    let client = this.clients.filter(client=>this.myControl.value==(client.firstName+" "+client.lastName))
    this.filteredObj.emit({
      'client':client,
      'filteredByField':this.filteredByField
    });
  }


}
