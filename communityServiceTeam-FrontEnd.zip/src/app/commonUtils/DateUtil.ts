export class DateUtil{
    // Convert the date string into a JavaScript Date object
    static convertToDate(dateString: string): Date {
    const parts = dateString.split('-');
  
    // Map month abbreviation to month number
    const months:any = {
      'Jan': 0, 'Feb': 1, 'Mar': 2, 'Apr': 3, 'May': 4, 'Jun': 5,
      'Jul': 6, 'Aug': 7, 'Sep': 8, 'Oct': 9, 'Nov': 10, 'Dec': 11
    };
  
    // Extract day, month, and year from the parts array
    const day = parseInt(parts[0]);
    const month = months[parts[1]];
    const year = parseInt(parts[2]) + (parseInt(parts[2]) < 50 ? 2000 : 1900); // Assuming 54 means 1954
  
    // Create and return the Date object
    return new Date(year, month, day);
  }
  
}