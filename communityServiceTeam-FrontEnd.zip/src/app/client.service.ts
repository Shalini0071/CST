import { Injectable } from '@angular/core';
import { client } from './models/Client';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ClientService {
  private _httpClient: any;

  constructor(_httpClient:HttpClient) { 
    this._httpClient=_httpClient;
  }
  clients:client[]|null=[];

  baseUrl:string="http://localhost:8080/cst/";

  getAllClients():Observable<HttpResponse<client[]>>{
    const url = this.baseUrl+"getAll";
    let getAllObs:Observable<HttpResponse<client[]>> =  this._httpClient.get(url,{observe:'response'});
    getAllObs.subscribe(res=>{
      if(res&&res.status==200){
        this.clients=res.body;
      }
    });
    return getAllObs;
  }

  getClientsArray(){
    return this.clients;
  }

  saveClient(client:client){
    const url = this.baseUrl+"save";
    return this._httpClient.post(url,client);
  }

  deleteClient(clientId:string){
    const url = this.baseUrl+"delete/"+clientId;
    return this._httpClient.delete(url,{observe:'response'});
    
  }

  

}
