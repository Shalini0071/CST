import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { MainComponent } from './main/main.component';
import { MatStepperModule } from '@angular/material/stepper';
import {MatInputModule } from '@angular/material/input';
import {MatFormFieldModule }from '@angular/material/form-field';
import { FormsModule, ReactiveFormsModule  } from '@angular/forms';
import {MatButtonModule} from '@angular/material/button'
import { MatStepLabel } from '@angular/material/stepper';
import {MatCardModule} from '@angular/material/card';
import { SearchClientComponent } from './search-client/search-client.component';
import { ClientListComponent } from './client-list/client-list.component';
import { CreateNewComponent } from './create-new/create-new.component';
import { EditClientComponent } from './edit-client/edit-client.component';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatIconModule } from '@angular/material/icon';
import { ElevatedDirective } from './elevated.directive';
import { provideNativeDateAdapter } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import {MatButtonToggleModule} from '@angular/material/button-toggle';
import {MatSlideToggleModule} from '@angular/material/slide-toggle';
import {MatTableModule} from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { RouterModule, Routes } from '@angular/router';
import { BasicComponent } from './basic/basic.component';
import { HttpClientModule } from '@angular/common/http';
import {MatSnackBarModule} from '@angular/material/snack-bar';
const routes: Routes =[{'path':'',component:BasicComponent},{'path':'view-list',component:ClientListComponent}];

@NgModule({
  declarations: [
    AppComponent,
    MainComponent,
    SearchClientComponent,
    ClientListComponent,
    CreateNewComponent,
    EditClientComponent,
    ElevatedDirective,
    BasicComponent
  ],
  imports: [MatDatepickerModule,FormsModule,MatTableModule,MatPaginatorModule,RouterModule.forRoot(routes),HttpClientModule,
    ReactiveFormsModule ,BrowserModule,BrowserAnimationsModule,MatStepperModule,MatIconModule,MatButtonToggleModule,MatSlideToggleModule,
    AppRoutingModule,MatFormFieldModule ,MatSnackBarModule, MatInputModule , MatButtonModule, MatStepLabel, MatCardModule,MatAutocompleteModule
  ],
  providers: [provideNativeDateAdapter()],
  bootstrap: [AppComponent]
})
export class AppModule { }

